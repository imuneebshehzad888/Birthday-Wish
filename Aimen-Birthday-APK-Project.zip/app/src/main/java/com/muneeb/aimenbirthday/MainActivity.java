package com.muneeb.aimenbirthday;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.content.Context;
import android.view.Gravity;
import android.view.View;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.TranslateAnimation;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import android.media.AudioTrack;
import android.media.AudioFormat;
import android.media.AudioManager;

public class MainActivity extends Activity {
    private static final String PASSWORD = "neebu";
    private final int pink = Color.rgb(255, 105, 180);
    private final int deepPurple = Color.rgb(57, 28, 77);
    private AudioTrack audioTrack;
    private volatile boolean musicPlaying = false;
    private Thread musicThread;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        showLockScreen();
    }

    private GradientDrawable gradient(int a, int b, int radius) {
        GradientDrawable d = new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{a,b});
        d.setCornerRadius(radius);
        return d;
    }

    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(color);
        t.setGravity(Gravity.CENTER);
        t.setFontFeatureSettings("kern");
        t.setTypeface(Typeface.create(bold ? "sans-serif" : "sans-serif-light", bold ? Typeface.BOLD : Typeface.NORMAL));
        t.setPadding(12, 8, 12, 8);
        return t;
    }

    private LinearLayout page() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setPadding(26, 28, 26, 28);
        root.setBackground(gradient(Color.rgb(49, 20, 69), Color.rgb(151, 55, 117), 0));
        return root;
    }

    private void showLockScreen() {
        LinearLayout root = page();
        TextView hearts = text("♡  ✨  ♡", 30, Color.WHITE, false);
        root.addView(hearts);
        TextView title = text("A Little Surprise\nfor Aimen ❤️", 30, Color.WHITE, true);
        title.setLineSpacing(4, 1f);
        root.addView(title);
        root.addView(text("A special little moment, made just for you", 15, Color.rgb(255, 224, 240), false));
        View gap = new View(this);
        root.addView(gap, new LinearLayout.LayoutParams(1, 24));
        EditText password = new EditText(this);
        password.setSingleLine(true);
        password.setHint("Enter your secret password");
        password.setHintTextColor(Color.rgb(225, 205, 230));
        password.setTextColor(Color.WHITE);
        password.setGravity(Gravity.CENTER);
        password.setInputType(129);
        password.setBackground(gradient(Color.rgb(100, 53, 112), Color.rgb(100, 53, 112), 50));
        password.setPadding(20, 12, 20, 12);
        root.addView(password, new LinearLayout.LayoutParams(-1, 58));

        Button unlock = new Button(this);
        unlock.setText("UNLOCK YOUR SURPRISE  ♥");
        unlock.setTextColor(Color.WHITE);
        unlock.setAllCaps(false);
        unlock.setTextSize(16);
        unlock.setBackground(gradient(Color.rgb(255, 90, 155), Color.rgb(222, 66, 142), 60));
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-1, 58);
        bp.setMargins(0, 18, 0, 0);
        root.addView(unlock, bp);
        root.addView(text("Made with love • From Muneeb", 14, Color.rgb(255, 225, 240), false));
        unlock.setOnClickListener(v -> {
            if (PASSWORD.equals(password.getText().toString())) {
                showBirthday();
            } else {
                Toast.makeText(this, "Not quite! Try the secret password ❤️", Toast.LENGTH_SHORT).show();
                password.setText("");
            }
        });
        setContentView(root);
        Animation fade = new AlphaAnimation(0f, 1f);
        fade.setDuration(900);
        root.startAnimation(fade);
    }

    private void showBirthday() {
        stopMusic();
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = page();
        root.setGravity(Gravity.TOP | Gravity.CENTER_HORIZONTAL);
        scroll.setBackgroundColor(deepPurple);
        scroll.addView(root);

        TextView sparkle = text("✦  ✨  ♡  ✨  ✦", 28, Color.rgb(255, 220, 245), false);
        root.addView(sparkle);
        TextView heading = text("Happy Birthday", 34, Color.WHITE, true);
        root.addView(heading);
        root.addView(text("AIMEN REHMAN", 23, Color.rgb(255, 211, 236), true));
        TextView cake = text("🎂", 76, Color.WHITE, false);
        root.addView(cake);
        TextView balloons = text("🎈  💗  🎈  💖  🎈", 30, Color.WHITE, false);
        root.addView(balloons);
        TranslateAnimation floaty = new TranslateAnimation(0, 0, 8, -12);
        floaty.setDuration(1300);
        floaty.setRepeatMode(Animation.REVERSE);
        floaty.setRepeatCount(Animation.INFINITE);
        cake.startAnimation(floaty);
        balloons.startAnimation(floaty);

        TextView happy = text("Happy Birthday to You! 🎉", 23, Color.WHITE, true);
        root.addView(happy);
        TextView message = text(
            "Yar Aimen, bohat bohat happy birthday! ❤️\n\n" +
            "Meri dil se dua hai ke tumhari zindagi hamesha khushiyon, sukoon aur kamyabiyon se bhari rahe. Tumhari smile hamesha aise hi chamakti rahe, aur tumhare har ache khwab ko haqeeqat banne ka mauqa mile.\n\n" +
            "May Allah bless you with endless happiness, good health, success and beautiful moments. Tumhari life ka har naya saal pichle saal se zyada khoobsurat ho.\n\n" +
            "Stay happy, keep smiling, and always be the wonderful person you are. Aaj ka din sirf tumhari khushi ke naam! 💕\n\n" +
            "Lots of duas and best wishes,\nMuneeb ❤️",
            18, Color.WHITE, false);
        message.setGravity(Gravity.CENTER);
        message.setLineSpacing(5, 1.12f);
        message.setBackground(gradient(Color.argb(60,255,255,255), Color.argb(30,255,255,255), 28));
        message.setPadding(18, 20, 18, 20);
        LinearLayout.LayoutParams mp = new LinearLayout.LayoutParams(-1, -2);
        mp.setMargins(0, 14, 0, 20);
        root.addView(message, mp);

        Button replay = new Button(this);
        replay.setText("Play the birthday tune ♪");
        replay.setAllCaps(false);
        replay.setTextColor(Color.WHITE);
        replay.setBackground(gradient(Color.rgb(255, 90, 155), Color.rgb(220, 70, 145), 50));
        root.addView(replay, new LinearLayout.LayoutParams(-1, 56));
        replay.setOnClickListener(v -> startMusic());
        root.addView(text("♡  Made especially for you by Muneeb  ♡", 14, Color.rgb(255, 218, 239), false));
        setContentView(scroll);

        Animation fade = new AlphaAnimation(0f, 1f);
        fade.setDuration(1100);
        root.startAnimation(fade);
        startMusic();
        sparkle.setOnClickListener(v -> {
            Toast.makeText(this, "Sending you lots of smiles, Aimen! 💖", Toast.LENGTH_SHORT).show();
        });
    }

    // A small synthesized celebratory melody; no external audio file or network is required.
    private void startMusic() {
        stopMusic();
        musicPlaying = true;
        musicThread = new Thread(() -> {
            int sampleRate = 22050;
            int min = AudioTrack.getMinBufferSize(sampleRate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT);
            if (min <= 0) return;
            try {
                audioTrack = new AudioTrack(AudioManager.STREAM_MUSIC, sampleRate,
                    AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT,
                    Math.max(min, 4096), AudioTrack.MODE_STREAM);
                audioTrack.play();
                int[] notes = {523, 659, 784, 659, 587, 698, 880, 698, 523, 659, 784, 1046, 880, 784};
                short[] buffer = new short[2048];
                while (musicPlaying) {
                    for (int freq : notes) {
                        if (!musicPlaying) break;
                        int samples = sampleRate / 3;
                        int done = 0;
                        while (done < samples && musicPlaying) {
                            int count = Math.min(buffer.length, samples - done);
                            for (int i = 0; i < count; i++) {
                                double envelope = Math.min(1.0, Math.min((done + i) / 300.0, (samples - done - i) / 500.0));
                                buffer[i] = (short)(Math.sin(2.0 * Math.PI * freq * (done + i) / sampleRate) * 1800 * Math.max(0, envelope));
                            }
                            audioTrack.write(buffer, 0, count);
                            done += count;
                        }
                        try { Thread.sleep(55); } catch (InterruptedException ignored) {}
                    }
                    try { Thread.sleep(350); } catch (InterruptedException ignored) {}
                }
            } catch (Exception ignored) {
            } finally {
                if (audioTrack != null) {
                    try { audioTrack.stop(); } catch (Exception ignored) {}
                    try { audioTrack.release(); } catch (Exception ignored) {}
                    audioTrack = null;
                }
            }
        });
        musicThread.start();
    }

    private void stopMusic() {
        musicPlaying = false;
        if (musicThread != null) {
            musicThread.interrupt();
            musicThread = null;
        }
        if (audioTrack != null) {
            try { audioTrack.pause(); } catch (Exception ignored) {}
            try { audioTrack.flush(); } catch (Exception ignored) {}
        }
    }

    @Override protected void onDestroy() {
        stopMusic();
        super.onDestroy();
    }
}
